const jwt = require("jsonwebtoken");
require("dotenv").config();
const secret = process.env.SECRET_KEY;

const generateJWT = async (rId, name, email) => {
  const payload = { rId, name, email };
  try {
    const token = await jwt.sign(payload, secret, {
      expiresIn: "30min",
    });
    return token;
  } catch (error) {
    throw new Error(`No se pudo generar el token ${error}`);
  }
};

module.exports = { generateJWT };