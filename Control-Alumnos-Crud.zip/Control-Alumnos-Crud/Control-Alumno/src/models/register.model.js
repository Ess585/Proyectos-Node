'use strict'

const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const RegisterSchema = Schema({
    name: {
        type: String,
        required: true,
    },
    email:{
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    rol:{
        type: String,
        required: true
    },
    age:{
        type: Number,
        required: false
    },
    cursos: [{
        nombre: String,
        codigoA: String,
        alumno: String
      }]
});

module.exports = mongoose.model('registers', RegisterSchema);
