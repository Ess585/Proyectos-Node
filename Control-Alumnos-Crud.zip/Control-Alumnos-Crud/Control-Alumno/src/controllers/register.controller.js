"use strict";

const Register = require("../models/register.model");
const bcrypt = require("bcrypt");
const { generateJWT } = require("../helpers/create-jwt");

//CRUD MAESTRO-ALUMNO
//AGREGAR
const createRegister = async (req, res) => {
  //if (req.regist.rol === "STUDENT") {
  const { name, email, password, rol, age } = req.body; 
    try {
        let regist = await Register.findOne({email: email});
        if(regist){
            return res.status(400).send({
                message: "Este correo ya se ha registrado",
                ok: false,
                regist: regist
            })
        }

    regist = new Register(req.body);
    const salt = bcrypt.genSaltSync();
    regist.password = bcrypt.hashSync(password, salt)
    regist = await regist.save();

    res.status(200).send({
        message: `El registro ${regist.name} ah sido creado correctamente`,
        regist
})
    } catch (error) {
        throw new Error(error)
    }
  /*} else {
    if (req.regist.rol === "TEACHER") {
      return res.status(500).send({
        message: "No se pueden asignar cursos a un maestro."
      })
    }
    //  Esta fue una forma que vi en internet pero no me funciono
    return res.status(500).send({
      message: "Este registro no tiene permisos para asignar cursos",
    });
  }*/
};

//LISTAR
const listRegister = async (req, res) => {
    try {
        const registers = await Register.find();
        if (!registers) {
            res.status(404).send({message: "No hay registros para mostrar"})
        } else {
            res.status(200).send({registros: registers})
        }
    } catch (error) {
        throw new Error("Hubo un problema al listar los registros")
    }
}

//ACTUALIZAR
const updateRegister = async(req, res) =>{
    try {
        const id = req.params.id;
        const editRegister = {...req.body};
        editRegister.password = editRegister.password
        ? bcrypt.hashSync(editRegister.password, bcrypt.genSaltSync())
        : editRegister.password;
        const registerComplete = await Register.findByIdAndUpdate(id, editRegister, {new: true});
        if (registerComplete) {
            return res.status(200).send({message: "Registro actualizado", registerComplete})
        } else {
            res.status(400).send({message: "Este usuario no existe en la base de Datos"});
        }
    } catch (error) {
        throw new Error(error);
    }
}

//ELIMINAR
const deleteRegister = async(req, res) =>{
    try {
        const id = req.params.id;
        const deleteRegister = await Register.findByIdAndDelete(id);
        return res.status(200).send({message: "Registro eliminado correctamente"}); 
        /*AWAIT: recibe la promesa y la convierte en un valor de retorno*/ 
    } catch (error) {
        throw new Error(error);
    }
}

//INICIAR SESION
const loginRegister = async (req, res) => {
    const { email, password } = req.body;
    try {
      const regist = await Register.findOne({ email });
      if (!regist) {
        return res
          .status(400)
          .send({ ok: false, message: "Los datos que buscas no han sido registrados" });
      }

      const validPassword = bcrypt.compareSync(
        password,
        regist.password
      );
      if (!validPassword) {
        return res
          .status(400)
          .send({ ok: false, message: "Contraseña Incorrecta" });
      }
  
      const token = await generateJWT(regist.id, regist.name, regist.email);
      res.json({
        ok: true,
        id: regist.id,
        name: regist.name,
        email: regist.email,
        token,
      });
    } catch (err) {
      throw new Error(err);
    }
  };


  //CRUD CURSOS
  //AGREGAR CURSO
  const addCourse = async (req, res) => {
      const { name, email} = req.body; 
      try {
        const id = req.params.id;
        const { nombre, codigoA, alumno } = req.body;
        const regist = await Register.findOne({ email });
        if (!regist) {
          return res
            .status(400)
            .send({ ok: false, message: "Los datos que buscas no han sido registrados" });
        }
    
        const registCourse = await Register.findByIdAndUpdate(id,
          {
            $push: {
              cursos: {
                nombre: nombre,
                codigoA: codigoA,
                alumno: alumno,
              },
            },
          },-
          { new: true }
        );
        if (!registCourse) {
          return res.status(404).send({ message: "No hemos encontrado este registro" });
        }
    
        return res.status(200).send({ message: "Te hemos asignado al curso", registCourse });
      } catch (error) {
        throw new Error(error);
      }
  };
  

  //ELIMINAR CURSO:
  const deleteCourse = async (req, res) => {
    const id = req.params.id;
    const { idCurso } = req.body;
    try {
      const elimCourse = await Register.updateOne(
        { id },
        {
          $pull: { cursos: { _id: idCurso } },
        },
        { new: true, multi: false }
      );
  
      if (!elimCourse) {
        return res.status(404).send({ message: "El registro no existe" });
      }
  
      return res.status(200).send({ message: `Curso eliminado`, elimCourse });
    } catch (error) {
      throw new Error(error);
    }
};
  
  //ACTUALIZAR CURSO:
  const updateCourse = async (req, res) => {
    const id = req.params.id;
    const { idCurso, nombre, codigoA, alumno } = req.body;
    try {
      const editCourse = await Register.updateOne(
        { _id: id, "curso._id": idCurso },
        {
          $set: {
            "curso.$.nombre": nombre,
            "curso.$.codigoA": codigoA,
            "curso.$.alumno": alumno,
          },
        },
        { new: true }
      );
  
      if (!editCourse) {
        return res.status(404).send({ message: "No existe este registro" });
      }
  
      return res
        .status(200)
        .send({ message: "Has sido asignado al curso de manera correcat", editCourse });
    } catch (error) {
      throw new Error(error);
    }
  };

//EXPORTACIONES
module.exports = 
{
    createRegister, 
    listRegister, 
    updateRegister, 
    deleteRegister,
    loginRegister,
    addCourse,
    deleteCourse,
    updateCourse
};

/*
    ORDEN PARA CREAR UNA FUNCION:
        ·funcion asincrona
        ·try catch
        ·(if else)
        ·(array)
        ·() son opcionales, estos iran segun lo que se quiera hacer el funcion
        · Los demas si son obligatorios, en la funciona se crean las promesas, peticiones y respuestas
          y en el try catch se establece la funcion de cada variable y su respuesta
*/
