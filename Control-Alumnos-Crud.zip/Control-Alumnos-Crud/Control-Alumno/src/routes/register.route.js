"use strict"

const express = require("express");
const { Router } = require("express");
const { 
    createRegister, 
    listRegister, 
    updateRegister, 
    deleteRegister, 
    loginRegister,
    addCourse, 
    deleteCourse,
    updateCourse
} = require("../controllers/register.controller");

const { check } = require("express-validator");
const { validateParams } = require("../middlewares/validate-params");
const { validateJWT } = require("../middlewares/validate-jwt");


const api = Router();

api.post(
    "/create-register",
/*[
  /*validateJWT,
  check("name", "El nombre de inicio es un campo obligatorio").not().isEmpty(),
  check("password", "La contraseña debe ser mayor a 5 digitos").isLength({
    min: 5,
  }),
  check("email", "El correo electronico es un obligatorio").not().isEmpty(),
  validateParams,
],*/
createRegister);

api.get("/list-register", listRegister);

api.put(
    "/update-register/:id",
[
  check("name", "El nombre de inicio es un campo obligatorio").not().isEmpty(),
  check("password", "La contraseña debe ser mayor a 5 digitos").isLength({
    min: 5,
  }),
  check("email", "El correo electronico es un obligatorio").not().isEmpty(),
  validateParams,
], 
updateRegister);

api.delete("/delete-register/:id", deleteRegister)
api.post("/login-register", loginRegister);

api.put("/add-course/:id", addCourse);
api.delete("/delete-course/:id", deleteCourse);
api.put("/update-course/:id", updateCourse);

module.exports = api;
